//
//  GameScene.swift
//  Pong
//
//  Created by Colin Smith on 2/11/19.
//  Copyright © 2019 Colin Smith. All rights reserved.
//

import SpriteKit
import GameplayKit

class GameScene: SKScene {
    
   var ball = SKSpriteNode()
    var player2 = SKSpriteNode()
    var player1 = SKSpriteNode()
    var score = [Int]()
    
    var player1ScoreLabel = SKLabelNode()
    var player2ScoreLabel = SKLabelNode()
    
    
    override func didMove(to view: SKView) {
        ball = self.childNode(withName: "ball") as! SKSpriteNode
        player2 = self.childNode(withName: "enemy") as! SKSpriteNode
        player1 = self.childNode(withName: "main") as! SKSpriteNode
        
        player1ScoreLabel = self.childNode(withName: "player1Score") as! SKLabelNode
        player2ScoreLabel = self.childNode(withName: "player2Score") as! SKLabelNode
        
        
        startGame()
        
        ball.physicsBody?.applyImpulse(CGVector(dx: -20, dy: -20))
        
        let border = SKPhysicsBody(edgeLoopFrom: self.frame)
        
        border.friction = 0
        border.restitution = 1
        
        self.physicsBody = border
        
        
        player1.position.y = -(self.frame.height/2) + 80
        player2.position.y = (self.frame.height/2) - 80
    }
    
    func startGame() {
        score = [0,0]
        player1ScoreLabel.text = "\(score[0])"
        player2ScoreLabel.text = "\(score[1])"
    }
    
    func addScore(playerWhoWon: SKSpriteNode) {
        
        ball.position = CGPoint(x: 0, y: 0)
        ball.physicsBody?.velocity = CGVector(dx: 0, dy: 0)
        
        if playerWhoWon == player2 {
            score[1] += 1
            player2ScoreLabel.text = "\(score[1])"
            
            ball.physicsBody?.applyImpulse(CGVector(dx: -Int.random(in: 10...25), dy: -Int.random(in: 10...25)))
            
        }
        else if playerWhoWon == player1 {
            score[0] += 1
            player1ScoreLabel.text = "\(score[0])"
            
            
            ball.physicsBody?.applyImpulse(CGVector(dx: Int.random(in: 10...25), dy: Int.random(in: 10...25)))
          
        }
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        
    }
    
    override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        
        for touch in touches{
            let location = touch.location(in: self)
            
            if location.y > 0 {
                player2.run(SKAction.moveTo(x: location.x, duration: 0.1))
            }
            if location.y < 0 {
               player1.run(SKAction.moveTo(x: location.x, duration: 0.1))
            }
            
        }
        
    }
    
   
    override func update(_ currentTime: TimeInterval) {
        // Called before each frame is rendered
    
        
        if ball.position.y <= player1.position.y - 50 {
            addScore(playerWhoWon: player2)
        }
        
        if ball.position.y >= player2.position.y + 50 {
            addScore(playerWhoWon: player1)
            
        }
    }
}
